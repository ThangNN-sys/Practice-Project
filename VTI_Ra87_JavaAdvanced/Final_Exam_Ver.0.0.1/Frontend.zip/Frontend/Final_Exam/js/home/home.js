function viewHomepage() {
    $(".main").load("./home/homePage.html");
}