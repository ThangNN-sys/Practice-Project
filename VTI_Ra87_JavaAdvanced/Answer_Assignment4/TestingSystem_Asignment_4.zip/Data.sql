/*============================== INSERT DATABASE =======================================*/
/*======================================================================================*/
-- Add data Address
INSERT INTO Address(AddressName) 
VALUES
				(N'P501'),
				(N'P502'),
				(N'P503'),
				(N'P504'),
				(N'P505'),
				(N'P401'),
				(N'P402'),
				(N'P403'),
				(N'P404'),
				(N'P405');

-- Add data Department
INSERT INTO Department(DepartmentName) 
VALUES
						(N'Marketing'	),
						(N'Sale'		),
						(N'Bảo vệ'		),
						(N'Nhân sự'		),
						(N'Kỹ thuật'	),
						(N'Tài chính'	),
						(N'Phó giám đốc'),
						(N'Giám đốc'	),
						(N'Thư kí'		),
						(N'Bán hàng'	);

-- Add data DetailDepartment
INSERT INTO DetailDepartment	(  DepartmentID		, AddressID, 	EmulationPoint)
VALUES 							(		1,				1,					1	),
								(		2,				2,					4	),
								(		3,				3,					6	),
								(		4,				4,					7	),
								(		5,				5,					2	),
								(		6,				6,					1	),
								(		7,				7,					5	),
								(		8,				8,					6	),
								(		9,				9,					8	),
								(		10,				10,					9	);
                    
-- Add data position
INSERT INTO Position	(`PositionName`	) 
VALUES 					('Dev'			),
						('Test'			),
						('ScrumMaster'	);
                        
-- Add data salary                 
INSERT INTO Salary		(SalaryName	) 
VALUES 					('600'		),
						('700'		),
						('1500'		);


-- Add data Account
INSERT INTO `Account`(Email								, Username			, FirstName,	LastName,		 DepartmentID	, PositionID, SalaryID, 	CreateDate)
VALUES 				('haidang29productions@gmail.com'	, 'dangblack'		,'Dang'	,		'Nguyen Hai'	,   '5'			,   '1',		'1'		,	'2020-03-05'),
					('account1@gmail.com'				, 'quanganh'		,'Anh'	,		'Tong Quang'	,   '1'			,   '2',		'2'		,	'2020-03-05'),
                    ('account2@gmail.com'				, 'vanchien'		,'Chien',		'Nguyen Van'	,   '2'			,   '3',		'3'		,	'2020-03-07'),
                    ('account3@gmail.com'				, 'cocoduongqua'	,'Do'	,		'Duong'			,   '3'			,   '3',		'3'		,	'2020-03-08'),
                    ('account4@gmail.com'				, 'doccocaubai'		,'Thang',		'Nguyen Chien'  ,   '4'			,   '3',		'3'		,	'2020-03-10'),
                    ('dapphatchetngay@gmail.com'		, 'khabanh'			,'Kha'	,		'Ngo Ba'		,   '6'			,   '3',		'3'		,	NOW()),
                    ('songcodaoly@gmail.com'			, 'huanhoahong'		,'Huan'	,		'Bui Xuan'		,   '7'			,   '2',		'2'		,	NOW()),
                    ('sontungmtp@gmail.com'				, 'tungnui'			,'Tung'	,		'Nguyen Thanh'	,   '8'			,   '1',		'1'		,	'2020-04-07'),
                    ('duongghuu@gmail.com'				, 'duongghuu'		,'Huu'	,		'Duong Van'		,   '9'			,   '2',		'2'		,	'2020-04-07'),
                    ('vtiaccademy@gmail.com'			, 'vtiaccademy'		,'Ai'	,		'Vi Ti'			,   '10'		,   '1',		'1'		,	'2020-04-09');

-- Add data Employee                 
INSERT INTO Employee	(AccountID,		WorkingNumberOfYear) 
VALUES 					(	1,					1			),
						(	2,					2			),
						(	3,					1			),
						(	4,					3			),
						(	5,					4			);

-- Add data Manager                 
INSERT INTO Manager		(AccountID,		ManagementNumberOfYear) 
VALUES 					(	6,					2			),
						(	7,					3			),
						(	8,					1			),
						(	9,					5			),   
                        (	10,					6			);
                        
-- Add data Group        
INSERT INTO `Group`	(  GroupName			, CreatorID		, CreateDate)
VALUES 				(N'Testing System'		,   5			,'2019-03-05'),
					(N'Developement'		,   1			,'2020-03-07'),
                    (N'VTI Sale 01'			,   2			,'2020-03-09'),
                    (N'VTI Sale 02'			,   3			,'2020-03-10'),
                    (N'VTI Sale 03'			,   4			,'2020-03-28'),
                    (N'VTI Creator'			,   6			,'2020-04-06'),
                    (N'VTI Marketing 01'	,   7			,'2020-04-07'),
                    (N'Management'			,   8			,'2020-04-08'),
                    (N'Chat with love'		,   9			,'2020-04-09'),
                    (N'Vi Ti Ai'			,   10			,'2020-04-10');

-- Add data GroupAccount
INSERT INTO `GroupAccount`	(  GroupID	, AccountID	, JoinDate	 )
VALUES 						(	1		,    1		,'2019-03-05'),
							(	1		,    2		,'2020-03-07'),
							(	3		,    3		,'2020-03-09'),
							(	3		,    4		,'2020-03-10'),
							(	5		,    5		,'2020-03-28'),
							(	1		,    3		,'2020-04-06'),
							(	1		,    7		,'2020-04-07'),
							(	8		,    3		,'2020-04-08'),
							(	1		,    9		,'2020-04-09'),
							(	10		,    10		,'2020-04-10');

-- Add data TypeQuestion
INSERT INTO TypeQuestion	(TypeName	) 
VALUES 						('0'), 
							('1'); 


-- Add data CategoryQuestion
INSERT INTO CategoryQuestion		(CategoryName	)
VALUES 								('Java'			),
									('ASP.NET'		),
									('ADO.NET'		),
									('SQL'			),
									('Postman'		),
									('Ruby'			),
									('Python'		),
									('C++'			),
									('C Sharp'		),
									('PHP'			);
													
-- Add data Question
INSERT INTO Question	(Content			, CategoryID, TypeID		, CreatorID	, CreateDate )
VALUES 					(N'Câu hỏi về Java'	,	1		,   '1'			,   '1'		,'2020-04-05'),
						(N'Câu Hỏi về PHP'	,	10		,   '2'			,   '2'		,'2020-04-05'),
						(N'Hỏi về C#'		,	9		,   '2'			,   '3'		,'2020-04-06'),
						(N'Hỏi về Ruby'		,	6		,   '1'			,   '4'		,'2020-04-06'),
						(N'Hỏi về Postman'	,	5		,   '1'			,   '5'		,'2020-04-06'),
						(N'Hỏi về ADO.NET'	,	3		,   '2'			,   '6'		,'2020-04-06'),
						(N'Hỏi về ASP.NET'	,	2		,   '1'			,   '7'		,'2020-04-06'),
						(N'Hỏi về C++'		,	8		,   '1'			,   '8'		,'2020-04-07'),
						(N'Hỏi về SQL'		,	4		,   '2'			,   '9'		,'2020-04-07'),
						(N'Hỏi về Python'	,	7		,   '1'			,   '10'	,'2020-04-07');

-- Add data Answers
INSERT INTO Answer	(  Content		, QuestionID	, isCorrect	)
VALUES 				(N'Trả lời 01'	,   1			,	0		),
					(N'Trả lời 02'	,   1			,	1		),
                    (N'Trả lời 03'	,   1			,	0		),
                    (N'Trả lời 04'	,   1			,	1		),
                    (N'Trả lời 05'	,   2			,	1		),
                    (N'Trả lời 06'	,   3			,	1		),
                    (N'Trả lời 07'	,   4			,	0		),
                    (N'Trả lời 08'	,   8			,	0		),
                    (N'Trả lời 09'	,   9			,	1		),
                    (N'Trả lời 10'	,   10			,	1		);
	
-- Add data Exam
INSERT INTO Exam	(`Code`			, Title					, CategoryID	, Duration	, CreatorID		, CreateDate )
VALUES 				('S-1'			, N'Đề thi C#'			,	1			,	60		,   '5'			,'2019-04-05'),
					('S-2'			, N'Đề thi PHP'			,	10			,	60		,   '1'			,'2019-04-05'),
                    ('M-1'			, N'Đề thi C++'			,	9			,	120		,   '2'			,'2019-04-07'),
                    ('S-3'			, N'Đề thi Java'		,	6			,	60		,   '3'			,'2020-04-08'),
                    ('M-2'			, N'Đề thi Ruby'		,	5			,	120		,   '4'			,'2020-04-10'),
                    ('S-4'			, N'Đề thi Postman'		,	3			,	60		,   '6'			,'2020-04-05'),
                    ('S-5'			, N'Đề thi SQL'			,	2			,	60		,   '7'			,'2020-04-05'),
                    ('S-6'			, N'Đề thi Python'		,	8			,	60		,   '8'			,'2020-04-07'),
                    ('L-1'			, N'Đề thi ADO.NET'		,	4			,	180		,   '9'			,'2020-04-07'),
                    ('L-2'			, N'Đề thi ASP.NET'		,	7			,	180		,   '10'		,'2020-04-08');
                    
-- Add data ExamQuestion
INSERT INTO ExamQuestion(ExamID	, QuestionID	) 
VALUES 					(	1	,		5		),
						(	2	,		10		), 
						(	3	,		4		), 
						(	4	,		3		), 
						(	5	,		7		), 
						(	6	,		10		), 
						(	7	,		2		), 
						(	8	,		10		), 
						(	9	,		9		), 
						(	10	,		8		); 